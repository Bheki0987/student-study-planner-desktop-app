﻿using System.Windows;

namespace StudentStudyPlanner.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
    }
}